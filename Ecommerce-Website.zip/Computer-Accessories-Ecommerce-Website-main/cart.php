<?php
//include header.php
include('header.php');
?>

<?php
//include cart items.php
include('Template/_cart-items.php')
?>

<?php
//include footer.php
include('footer.php');
?>
