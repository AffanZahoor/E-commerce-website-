<!--coming soon items-->
<section id="Products">
    <div class="container py-5">
        <h4 class="font-rubik font-size-20">Products</h4>
        <div class="row">
            <div class="column">
                <div class="item py-2" style="width:200px;">
                    <div class="product font-rale">
                        <img src="./Assests/cs6.jpg" alt="product1" style="width:100%">
                        <div class="text-center">
                            <h6>Samsung Odyssey G11</h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="column">
                <div class="item py-2" style="width:200px;">
                    <div class="product font-rale">
                        <img src="./Assests/cs5.jpg" alt="product2" style="width:100%">
                        <div class="text-center">
                            <h6>Nvidia Quadro RTX 5000</h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="column">
                <div class="item py-2" style="width:200px;">
                    <div class="product font-rale">
                        <img src="./Assests/cs4.jpg" alt="product2" style="width:100%">
                        <div class="text-center">
                            <h6>GM 300</h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="column">
                <div class="item py-2" style="width:200px;">
                    <div class="product font-rale">
                        <img src="./Assests/cs3.jpg" alt="product2" style="width:100%">
                        <div class="text-center">
                            <h6>Razor Tron</h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="column">
                <div class="item py-2" style="width:200px;">
                    <div class="product font-rale">
                        <img src="./Assests/cs2.jpg" alt="product2" style="width:100%">
                        <div class="text-center">
                            <h6>System 76</h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="column">
                <div class="item py-2" style="width:200px;">
                    <div class="product font-rale">
                        <img src="./Assests/cs1.jpg" alt="product2" style="width:100%">
                        <div class="text-center">
                            <h6>Logitech Salvo</h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="column">
                <div class="item py-2" style="width:200px;">
                    <div class="product font-rale">
                        <img src="./Assests/product6.jpg" alt="product2" style="width:100%">
                        <div class="text-center">
                            <h6>Core I9 14900 14th Gen</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--!coming soon items-->