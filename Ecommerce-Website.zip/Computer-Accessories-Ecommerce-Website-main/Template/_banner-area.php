<!-- Thumbnail -->
<div class="item">
    <img src="./Assests/Banner1.jpg" alt="banner">
</div>
<!--!Thumbnail-->